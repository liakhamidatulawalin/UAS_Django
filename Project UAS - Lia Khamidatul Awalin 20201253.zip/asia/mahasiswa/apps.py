from django.apps import AppConfig


class MahasiswaConfig(AppConfig):
    name = 'mahasiswa'
